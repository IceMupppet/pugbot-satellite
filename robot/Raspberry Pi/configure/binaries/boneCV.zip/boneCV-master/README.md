boneCV
======

Beaglebone Webcam and OpenCV Examples Repository.

Copyright Derek Molloy, School of Electronic Engineering, Dublin City University

Redistribution and use in source and binary forms, with or without modification, are permitted
provided that source code redistributions retain this notice.

This software is provided AS IS and it comes with no warranties of any type. 

The description of the code presented here is on the website: www.derekmolloy.ie. If you use this code 
or the content of the associated video in your research, please cite:

Molloy, D. [DerekMolloyDCU]. (2013, May, 25). Beaglebone: Video Capture and Image Processing 
on Embedded Linux using OpenCV [Video file]. Retrieved from http://www.youtube.com/watch?v=8QouvYMfmQo

Please find more information on these videos at: http://www.derekmolloy.ie/  


